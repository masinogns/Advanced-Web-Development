# Todo List 만들기

> 간단한 Todo 리스트 관리 웹어플리케이션을 만들어 본다


## 준비하기

[기본 프로그램 설치](https://advanced-webapps-class.github.io/front-end-start/intro/ready.html)


## 기본 소스설치 및 로컬 웹서버 올리기

[기본 소스 내려받기](https://github.com/advanced-webapps-class/todo-webapp/releases/tag/0.1)

```
$ cd todo-webapp
$ serve .
```

## 브라우저로 열기
chrome 으로 http://localhost:3000 열기 